import os
import requests
import json
import time
from typing import List, TypedDict, Optional

from langchain_core.tools import tool

def _get_confluence_auth_details():
    """
    Helper to get Confluence authentication details.
    WARNING: Hardcoding credentials is highly insecure. For production,
    use environment variables or a secure secret management system.
    """
    CONFLUENCE_BASE_URL = os.getenv("CONFLUENCE_BASE_URL", "https://oneconfluence.verizon.com")
    CONFLUENCE_USERNAME = os.getenv("CONFLUENCE_USERNAME")
    CONFLUENCE_PASSWORD = os.getenv("CONFLUENCE_PASSWORD")

    if not CONFLUENCE_USERNAME or not CONFLUENCE_PASSWORD:
        raise ValueError("CONFLUENCE_USERNAME and CONFLUENCE_PASSWORD must be set (preferably via environment variables).")
    
    return CONFLUENCE_BASE_URL, CONFLUENCE_USERNAME, CONFLUENCE_PASSWORD

@tool
def get_confluence_page_content(space_key: str, page_title: str) -> str:
    """
    Retrieves the content of a specific Confluence page.
    This tool is used by the agent to read pages and understand their content.

    Args:
        space_key (str): The key of the Confluence space where the page resides.
        page_title (str): The exact title of the page to retrieve.
    Returns:
        str: The storage format content of the page, or an error message.
    """
    CONFLUENCE_BASE_URL, CONFLUENCE_USERNAME, CONFLUENCE_PASSWORD = _get_confluence_auth_details()
    auth = (CONFLUENCE_USERNAME, CONFLUENCE_PASSWORD)
    headers = {"Content-Type": "application/json"}

    print(f"[LOG] Attempting to retrieve content for page '{page_title}' in space '{space_key}'...")
    search_url = f"{CONFLUENCE_BASE_URL}/rest/api/content"
    params = {
        "title": page_title,
        "spaceKey": space_key,
        "expand": "body.storage"
    }
    try:
        resp = requests.get(search_url, auth=auth, headers=headers, params=params)
        resp.raise_for_status()
        data = resp.json()

        if "results" in data and len(data["results"]) > 0:
            page_content = data["results"][0]["body"]["storage"]["value"]
            print(f"[LOG] Successfully retrieved content for page '{page_title}'.")
            return page_content
        else:
            print(f"[LOG] Page '{page_title}' not found in space '{space_key}'.")
            return f"Error: Page '{page_title}' not found in space '{space_key}'."
    except requests.exceptions.RequestException as e:
        print(f"[ERROR] Failed to retrieve content for page '{page_title}': {e}")
        return f"Error: Failed to retrieve content for page '{page_title}'. Details: {e}"

@tool
def append_content_to_cloud_page(destination_space_key: str, cloud_page_title: str, content_to_append: str) -> str:
    """
    Appends content to an existing cloud provider's page (AWS, Azure, GCP) in the destination space.
    If the cloud page does not exist, it creates it with the provided content.
    It checks if the exact content is already present before appending.

    Args:
        destination_space_key (str): The key of the destination Confluence space.
        cloud_page_title (str): The title of the cloud provider's page (e.g., "AWS", "Azure", "GCP").
        content_to_append (str): The content from the source page to append.
    Returns:
        str: A summary message of the operation.
    """
    CONFLUENCE_BASE_URL, CONFLUENCE_USERNAME, CONFLUENCE_PASSWORD = _get_confluence_auth_details()
    auth = (CONFLUENCE_USERNAME, CONFLUENCE_PASSWORD)
    headers = {"Content-Type": "application/json"}

    print(f"\n--- Starting Content Appending Operation ---")
    print(f"Destination Space: '{destination_space_key}', Target Cloud Page: '{cloud_page_title}'")

    # --- Step 1: Search for the target cloud page and get its current content ---
    search_url = f"{CONFLUENCE_BASE_URL}/rest/api/content"
    params = {
        "title": cloud_page_title,
        "spaceKey": destination_space_key,
        "expand": "version,body.storage" # Need version for update, and current content
    }
    
    page_id = None
    current_version = 0
    existing_content = ""

    try:
        print(f"[LOG] Searching for cloud page: '{cloud_page_title}' in space '{destination_space_key}'...")
        resp = requests.get(search_url, auth=auth, headers=headers, params=params)
        resp.raise_for_status()
        data = resp.json()

        if "results" in data and len(data["results"]) > 0:
            page = data["results"][0]
            page_id = page["id"]
            current_version = page["version"]["number"]
            existing_content = page["body"]["storage"]["value"]
            print(f"[LOG] Cloud page '{cloud_page_title}' found. ID: {page_id}, Version: {current_version}.")
            print(f"[DEBUG] Existing content snippet: {existing_content[:100]}...")
        else:
            print(f"[LOG] Cloud page '{cloud_page_title}' not found. Will attempt to create it.")

    except requests.exceptions.RequestException as e:
        print(f"[ERROR] Failed to search for cloud page '{cloud_page_title}': {e}. Assuming page does not exist and attempting to create if content is new.")
        # If search fails, assume page doesn't exist and proceed to create if content is new.

    # --- Step 2: Check if content_to_append is already present ---
    if content_to_append in existing_content:
        print(f"[INFO] The content to append is already present in page '{cloud_page_title}'. No changes will be made.")
        return f"Content from source page already exists in Confluence page '{cloud_page_title}'. No update performed."

    # --- Step 3: Append or Create Content ---
    new_content_block = f"<p>--- Content from Source Page: {time.strftime('%Y-%m-%d %H:%M:%S')} ---</p>{content_to_append}<p>--- End of Source Page Content ---</p>"
    new_page_content = f"{existing_content}{new_content_block}"

    if page_id: # Page exists, so update it
        update_url = f"{CONFLUENCE_BASE_URL}/rest/api/content/{page_id}"
        payload = {
            "id": page_id,
            "type": "page",
            "title": cloud_page_title,
            "space": {"key": destination_space_key},
            "body": {
                "storage": {
                    "value": new_page_content,
                    "representation": "storage"
                }
            },
            "version": {"number": current_version + 1}
        }
        try:
            print(f"[LOG] Sending PUT request to update page '{cloud_page_title}'...")
            update_resp = requests.put(update_url, auth=auth, headers=headers, json=payload)
            update_resp.raise_for_status()
            print(f"[SUCCESS] Successfully appended content to page '{cloud_page_title}'.")
            return f"Successfully appended content to Confluence page '{cloud_page_title}' in space '{destination_space_key}'."
        except requests.exceptions.RequestException as e:
            print(f"[ERROR] Failed to update page '{cloud_page_title}': {e}")
            return f"Error: Failed to append content to page '{cloud_page_title}'. Details: {e}"
    else: # Page does not exist, so create it
        create_url = f"{CONFLUENCE_BASE_URL}/rest/api/content"
        payload = {
            "type": "page",
            "title": cloud_page_title,
            "space": {"key": destination_space_key},
            "body": {
                "storage": {
                    "value": new_page_content,
                    "representation": "storage"
                }
            }
        }
        try:
            print(f"[LOG] Sending POST request to create new page '{cloud_page_title}'...")
            create_resp = requests.post(create_url, auth=auth, headers=headers, json=payload)
            create_resp.raise_for_status()
            created_page_data = create_resp.json()
            print(f"[SUCCESS] Successfully created new page '{cloud_page_title}' with content. New ID: {created_page_data['id']}")
            return f"Successfully created Confluence page '{cloud_page_title}' in space '{destination_space_key}' and added content."
        except requests.exceptions.RequestException as e:
            print(f"[ERROR] Failed to create page '{cloud_page_title}': {e}")
            return f"Error: Failed to create page '{cloud_page_title}'. Details: {e}"