import asyncio
import os
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

from langchain_core.messages import HumanMessage
from agent.confluence_agent import confluence_agent_app

async def main():
    print("[LOG] Entering main() function.")
    try:
        SOURCE_SPACE_KEY = os.getenv("SOURCE_SPACE_KEY", "CLOUD")   
        PAGE_TITLE_TO_COPY = os.getenv("PAGE_TITLE_TO_COPY", "AWS Services being Tagged") 
        DESTINATION_SPACE_KEY = os.getenv("DESTINATION_SPACE_KEY", "VZNOV") 

        print("\n" + "="*80)
        print(f"                       STARTING CLOUD CONTENT MIGRATION REQUEST                      ")
        print("="*80 + "\n")
        print(f"Request: Copy content of page '{PAGE_TITLE_TO_COPY}' from '{SOURCE_SPACE_KEY}' to append into its respective cloud page in '{DESTINATION_SPACE_KEY}'.")

        inputs = {
            "messages": [HumanMessage(content=f"Please take the content of the page titled '{PAGE_TITLE_TO_COPY}' from space '{SOURCE_SPACE_KEY}' and append it to the relevant cloud provider's page in space '{DESTINATION_SPACE_KEY}'.")],
            "source_space_key": SOURCE_SPACE_KEY,
            "page_title_to_copy": PAGE_TITLE_TO_COPY,
            "destination_space_key": DESTINATION_SPACE_KEY
        }

        final_state = await confluence_agent_app.ainvoke(inputs)
        
        print("\n--- FINAL CLOUD CONTENT MIGRATION RESPONSE ---")
        # Access the status
        operation_status = final_state.get("status", "unknown") 
        print(f"Overall Status: {operation_status.upper()}")

        if final_state and "messages" in final_state and final_state["messages"]:
            print("Final Message:")
            print(final_state["messages"][-1].content)
        else:
            print("No final message from the workflow.")

    except Exception as e:
        print(f"\n[CRITICAL ERROR] An unexpected error occurred during main execution: {e}")
        print(f"Overall Status: FAILURE") # Indicate failure for critical errors

if __name__ == "__main__":
    asyncio.run(main())