import asyncio
import os
from dotenv import load_dotenv
from langchain_core.messages import HumanMessage
from agents.confluence_agent import confluence_agent_app

# Load environment
load_dotenv()

# Shared function to be used both locally and by FastAPI
async def run_kma_agent():
    SOURCE_SPACE_KEY = os.getenv("SOURCE_SPACE_KEY", "CLOUD")
    PAGE_TITLE_TO_COPY = os.getenv("PAGE_TITLE_TO_COPY", "AWS Services being Tagged")
    DESTINATION_SPACE_KEY = os.getenv("DESTINATION_SPACE_KEY", "VZNOV")

    inputs = {
        "messages": [HumanMessage(content=f"Please take the content of the page titled '{PAGE_TITLE_TO_COPY}' from space '{SOURCE_SPACE_KEY}' and append it to the relevant cloud provider's page in space '{DESTINATION_SPACE_KEY}'.")],
        "source_space_key": SOURCE_SPACE_KEY,
        "page_title_to_copy": PAGE_TITLE_TO_COPY,
        "destination_space_key": DESTINATION_SPACE_KEY
    }

    final_state = await confluence_agent_app.ainvoke(inputs)
    return final_state

# Local execution entry point
async def main():
    print("[INFO] Running KMA agent locally...\n")
    result = await run_kma_agent()
    print("\n[RESULT STATUS]:", result.get("status", "unknown"))
    if result.get("messages"):
        print("[FINAL MESSAGE]:", result["messages"][-1].content)
    else:
        print("[FINAL MESSAGE]: None")

if __name__ == "__main__":
    asyncio.run(main())
