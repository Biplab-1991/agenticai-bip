#uvicorn server:app --reload to run locally

from fastapi import FastAPI
import asyncio
from main import run_kma_agent  # local import from same dir

app = FastAPI(title="KMA Agent API")

@app.post("/run")
def trigger_kma():
    try:
        result = asyncio.run(run_kma_agent())
        message = result.get("messages", [])
        return {
            "status": result.get("status", "unknown"),
            "message": message[-1].content if message else "No message returned."
        }
    except Exception as e:
        return {
            "status": "error",
            "message": str(e)
        }
